'use strict';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'citationSaverLink',
    title: 'Get citation link',
    contexts: [ 'selection' ]
  });
});

chrome.contextMenus.onClicked.addListener(() => {
  chrome.tabs.executeScript({ file: 'contentScripts/processSelection.js' });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: 'https://johnpleung.github.io/citation-saver/#czoidGhhIixlOiJlci4iLGExOiJ0Mzt3Mjt5MiIsYTI6InQxO2kxO2w1Iix2OjE=' });
});