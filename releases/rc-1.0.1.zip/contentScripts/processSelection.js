"use strict";
citationSaver.main.processSelection();